import React, { useState } from 'react';
import { format } from 'date-fns';
import { Comment } from '../types/blog';

interface CommentSectionProps {
  comments: Comment[];
  postId: number;
}

const CommentSection: React.FC<CommentSectionProps> = ({ comments, postId }) => {
  const [newComment, setNewComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle comment submission
    setNewComment('');
  };

  return (
    <div className="space-y-8">
      <h3 className="text-2xl font-bold tracking-tight">Comments</h3>
      
      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Share your thoughts..."
          className="w-full bg-white/5 border border-white/10 p-4 text-white placeholder-gray-400 focus:outline-none focus:border-white/30 transition-colors min-h-[100px]"
        />
        <button
          type="submit"
          className="px-6 py-2 bg-white text-black hover:bg-gray-200 transition-all tracking-wide"
        >
          Post Comment
        </button>
      </form>

      {/* Comments List */}
      <div className="space-y-6">
        {comments.map((comment) => (
          <div key={comment.id} className="border-b border-white/10 pb-6">
            <div className="flex items-start gap-4">
              <img
                src={comment.avatar}
                alt={comment.author}
                className="w-10 h-10 rounded-full"
              />
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-bold">{comment.author}</span>
                  <span className="text-sm text-gray-400">
                    {format(new Date(comment.date), 'MMM d, yyyy')}
                  </span>
                </div>
                <p className="text-gray-300">{comment.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentSection;