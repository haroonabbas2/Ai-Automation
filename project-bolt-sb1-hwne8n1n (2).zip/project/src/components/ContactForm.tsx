import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Circle, ArrowLeft, Check, X } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface FormData {
  full_name: string;
  email: string;
  company_name: string;
  service: string;
  problem_description: string;
  additional_info: string;
}

const ContactForm: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    full_name: '',
    email: '',
    company_name: '',
    service: '',
    problem_description: '',
    additional_info: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errors, setErrors] = useState<Partial<FormData>>({});

  const validateForm = () => {
    const newErrors: Partial<FormData> = {};
    if (!formData.full_name) newErrors.full_name = 'Full name is required';
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.company_name) newErrors.company_name = 'Company name is required';
    if (!formData.service) newErrors.service = 'Please select a service';
    if (!formData.problem_description) newErrors.problem_description = 'Problem description is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const { error } = await supabase
        .from('contact_submissions')
        .insert([formData]);

      if (error) throw error;

      setSubmitStatus('success');
      setTimeout(() => {
        navigate('/');
      }, 3000);
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormData]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/50 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Circle className="w-8 h-8 text-white" />
              <span className="ml-2 text-xl font-bold text-glow tracking-wider">TRW.AI</span>
            </div>
            <button
              onClick={() => navigate('/')}
              className="flex items-center text-gray-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      {/* Form Section */}
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white/5 border border-white/10 p-8 rounded-none">
            <h1 className="text-3xl font-bold mb-2 text-glow tracking-tight">
              Start Your AI Automation Journey
            </h1>
            <p className="text-gray-400 mb-8 tracking-wide">
              Tell us about your needs and we'll help you find the perfect AI automation solution for your business.
            </p>

            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 text-green-400 flex items-center">
                <Check className="w-5 h-5 mr-2" />
                Form submitted successfully! Redirecting...
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 flex items-center">
                <X className="w-5 h-5 mr-2" />
                An error occurred. Please try again.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="full_name" className="block text-sm font-medium text-gray-300 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="full_name"
                  name="full_name"
                  value={formData.full_name}
                  onChange={handleInputChange}
                  className={`w-full bg-white/5 border ${errors.full_name ? 'border-red-500/50' : 'border-white/10'} p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors`}
                  placeholder="Enter your full name"
                />
                {errors.full_name && (
                  <p className="mt-1 text-sm text-red-400">{errors.full_name}</p>
                )}
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full bg-white/5 border ${errors.email ? 'border-red-500/50' : 'border-white/10'} p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors`}
                  placeholder="Enter your email address"
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-400">{errors.email}</p>
                )}
              </div>

              <div>
                <label htmlFor="company_name" className="block text-sm font-medium text-gray-300 mb-2">
                  Company Name *
                </label>
                <input
                  type="text"
                  id="company_name"
                  name="company_name"
                  value={formData.company_name}
                  onChange={handleInputChange}
                  className={`w-full bg-white/5 border ${errors.company_name ? 'border-red-500/50' : 'border-white/10'} p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors`}
                  placeholder="Enter your company name"
                />
                {errors.company_name && (
                  <p className="mt-1 text-sm text-red-400">{errors.company_name}</p>
                )}
              </div>

              <div>
                <label htmlFor="service" className="block text-sm font-medium text-gray-300 mb-2">
                  Service *
                </label>
                <select
                  id="service"
                  name="service"
                  value={formData.service}
                  onChange={handleInputChange}
                  className={`w-full bg-white/5 border ${errors.service ? 'border-red-500/50' : 'border-white/10'} p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors`}
                >
                  <option value="" className="bg-black">Select a service</option>
                  <option value="AI Agent" className="bg-black">AI Agent</option>
                  <option value="AI Phone Agent" className="bg-black">AI Phone Agent</option>
                  <option value="Email Automation" className="bg-black">Email Automation</option>
                  <option value="Social Media Automation" className="bg-black">Social Media Automation</option>
                </select>
                {errors.service && (
                  <p className="mt-1 text-sm text-red-400">{errors.service}</p>
                )}
              </div>

              <div>
                <label htmlFor="problem_description" className="block text-sm font-medium text-gray-300 mb-2">
                  What problems are you looking to solve? *
                </label>
                <textarea
                  id="problem_description"
                  name="problem_description"
                  value={formData.problem_description}
                  onChange={handleInputChange}
                  rows={4}
                  className={`w-full bg-white/5 border ${errors.problem_description ? 'border-red-500/50' : 'border-white/10'} p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors`}
                  placeholder="Please describe the challenges you're facing..."
                />
                {errors.problem_description && (
                  <p className="mt-1 text-sm text-red-400">{errors.problem_description}</p>
                )}
              </div>

              <div>
                <label htmlFor="additional_info" className="block text-sm font-medium text-gray-300 mb-2">
                  Additional Information
                </label>
                <textarea
                  id="additional_info"
                  name="additional_info"
                  value={formData.additional_info}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full bg-white/5 border border-white/10 p-3 text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors"
                  placeholder="Share any other relevant details..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-4 px-8 bg-white text-black text-lg font-medium transition-all ring-glow
                  ${isSubmitting ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-200'}`}
              >
                {isSubmitting ? 'Submitting...' : 'Schedule Consultation'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactForm;