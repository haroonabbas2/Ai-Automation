export const removeSplineLogo = () => {
  const checkAndRemoveLogo = () => {
    const splineViewer = document.querySelector('spline-viewer');
    if (!splineViewer) return;

    // Access shadow DOM
    const shadowRoot = splineViewer.shadowRoot;
    if (!shadowRoot) return;

    // Find and remove the bottom logo
    const bottomLogo = shadowRoot.querySelector('div[style*="position: absolute"][style*="bottom: 0"]');
    if (bottomLogo) {
      bottomLogo.style.display = 'none';
    }

    // Find and remove the top logo
    const topLogo = shadowRoot.querySelector('div[style*="position: absolute"][style*="top: 0"]');
    if (topLogo) {
      topLogo.style.display = 'none';
    }

    // Additional check for any remaining spline branding
    const allLogos = shadowRoot.querySelectorAll('a[href*="spline.design"]');
    allLogos.forEach(logo => {
      const parentDiv = logo.closest('div');
      if (parentDiv) {
        parentDiv.style.display = 'none';
      }
    });
  };

  // Initial check
  checkAndRemoveLogo();

  // Set up a MutationObserver to watch for changes
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        checkAndRemoveLogo();
      }
    });
  });

  // Start observing the document for when the spline-viewer is added
  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // Cleanup function
  return () => observer.disconnect();
};