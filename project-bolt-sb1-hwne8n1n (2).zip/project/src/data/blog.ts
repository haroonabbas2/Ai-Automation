import { Author, BlogPost, Comment } from '../types/blog';

export const authors: Author[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'AI Solutions Architect',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
    bio: 'Sarah is a leading expert in AI automation with over 10 years of experience in implementing enterprise-scale solutions.'
  },
  {
    id: '2',
    name: 'Marcus Rodriguez',
    role: 'Lead Generation Specialist',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    bio: 'Marcus specializes in developing data-driven lead generation strategies for businesses across various industries.'
  }
];

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "How AI Automation Transforms Business Operations",
    slug: "ai-automation-transforms-business",
    excerpt: "Discover how AI-powered automation is revolutionizing business processes and driving efficiency across industries.",
    content: `
# How AI Automation Transforms Business Operations

Artificial Intelligence (AI) is revolutionizing the way businesses operate, creating unprecedented opportunities for efficiency, growth, and innovation. In this comprehensive guide, we'll explore how AI automation is transforming various aspects of business operations and what this means for the future of work.

## The Impact of AI Automation

AI automation is fundamentally changing how businesses approach their operations, from customer service to internal processes. Here are some key areas where AI is making a significant impact:

1. Customer Service
- 24/7 availability through AI chatbots
- Personalized customer interactions
- Faster response times
- Improved customer satisfaction

2. Process Automation
- Streamlined workflows
- Reduced manual errors
- Increased productivity
- Cost savings

3. Data Analysis
- Real-time insights
- Predictive analytics
- Better decision-making
- Trend identification

## Implementation Strategies

Successfully implementing AI automation requires a strategic approach:

1. Assessment
- Identify automation opportunities
- Evaluate current processes
- Define success metrics

2. Planning
- Set clear objectives
- Choose appropriate solutions
- Create implementation timeline

3. Execution
- Deploy solutions gradually
- Monitor performance
- Gather feedback
- Make adjustments

## Future Outlook

The future of AI automation in business operations looks promising:

- Increased adoption across industries
- More sophisticated AI capabilities
- Greater integration with existing systems
- Enhanced ROI potential

## Conclusion

AI automation is no longer just a trend—it's becoming a necessity for businesses looking to remain competitive in today's fast-paced market. By embracing these technologies now, companies can position themselves for success in the increasingly automated future of business operations.
    `,
    coverImage: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1200',
    author: authors[0],
    date: "2024-03-26",
    readTime: "5 min read",
    categories: ["AI", "Automation"],
    tags: ["AI", "Business Automation", "Digital Transformation", "Efficiency"]
  },
  // Add more blog posts here...
];

export const comments: Comment[] = [
  {
    id: 1,
    postId: 1,
    author: "John Smith",
    content: "Great insights on AI automation! We've implemented similar solutions in our company and seen remarkable improvements in efficiency.",
    date: "2024-03-26T10:30:00Z",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100"
  },
  {
    id: 2,
    postId: 1,
    author: "Emily Johnson",
    content: "The implementation strategies section was particularly helpful. Would love to see more detailed case studies in future posts.",
    date: "2024-03-26T11:15:00Z",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100"
  }
];