import React, { useEffect, useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { Brain, MessageSquare, Database, ArrowRight, Circle } from 'lucide-react';
import { removeSplineLogo } from './utils/removeSplineLogo';
import ConsultationPage from './pages/ConsultationPage';
import AboutPage from './pages/AboutPage';
import BlogPage from './pages/BlogPage';
import BlogPostPage from './pages/BlogPostPage';

function App() {
  const [isVisible, setIsVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setIsVisible(true);
    const cleanup = removeSplineLogo();
    return cleanup;
  }, []);

  const handleBookCall = () => {
    navigate('/consultation');
  };

  const handleAbout = () => {
    navigate('/about');
  };

  const handleBlog = () => {
    navigate('/blog');
  };

  return (
    <Routes>
      <Route path="/consultation" element={<ConsultationPage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/blog" element={<BlogPage />} />
      <Route path="/blog/:slug" element={<BlogPostPage />} />
      <Route path="/" element={
        <div className="min-h-screen bg-black text-white">
          {/* Navigation */}
          <nav className="fixed w-full z-50 bg-black/50 backdrop-blur-lg border-b border-white/10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Circle className="w-8 h-8 text-white" />
                  <span className="ml-2 text-xl font-bold text-glow tracking-wider">TRW.AI</span>
                </div>
                <div className="hidden md:flex space-x-8">
                  <button 
                    onClick={handleAbout}
                    className="text-gray-300 hover:text-white transition-colors tracking-wide"
                  >
                    About
                  </button>
                  <button 
                    onClick={handleBlog}
                    className="text-gray-300 hover:text-white transition-colors tracking-wide"
                  >
                    Blog
                  </button>
                  <button 
                    onClick={handleBookCall}
                    className="px-6 py-2 bg-white text-black hover:bg-gray-200 transition-all ring-glow tracking-wide"
                  >
                    Book a Call
                  </button>
                </div>
              </div>
            </div>
          </nav>

          {/* Hero Section */}
          <section className="relative min-h-screen">
            {/* Spline Animation Container */}
            <div className="absolute inset-0 z-0">
              <spline-viewer url="https://prod.spline.design/K8DugpAv9ziAjSRv/scene.splinecode"></spline-viewer>
            </div>

            {/* Content Layer */}
            <div className="relative z-10 pt-32 pb-20 px-4">
              <div className="max-w-7xl mx-auto text-center">
                <div className={`transition-all duration-1000 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                  <h1 className="text-4xl md:text-6xl font-bold mb-6 text-glow tracking-tight leading-tight">
                    <span className="typewriter inline-block">Automate Your Business</span>
                    <br />
                    <span className="text-white/80">With Advanced AI</span>
                  </h1>
                  <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto tracking-wide">
                    Transform your customer interactions with intelligent chat agents, automated lead generation, and seamless CRM integration.
                  </p>
                  <div className="flex justify-center gap-4">
                    <button 
                      onClick={handleBookCall}
                      className="px-8 py-4 bg-white text-black text-lg hover:bg-gray-200 transition-all ring-glow tracking-wide"
                    >
                      Get Started
                    </button>
                    <button 
                      onClick={handleAbout}
                      className="px-8 py-4 border border-white text-white text-lg hover:bg-white/5 transition-all tracking-wide"
                    >
                      Learn More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Features Grid */}
          <section className="py-20 px-4" id="features">
            <div className="max-w-7xl mx-auto">
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-none border border-white/10 hover:border-white/30 transition-all bg-white/5">
                  <Brain className="w-12 h-12 text-white mb-4 floating" />
                  <h3 className="text-xl font-bold mb-4 tracking-wide">AI Chat Agents</h3>
                  <p className="text-gray-400 tracking-wide">Intelligent conversational agents that understand context and deliver personalized responses.</p>
                </div>
                <div className="p-8 rounded-none border border-white/10 hover:border-white/30 transition-all bg-white/5">
                  <MessageSquare className="w-12 h-12 text-white mb-4 floating" />
                  <h3 className="text-xl font-bold mb-4 tracking-wide">Lead Generation</h3>
                  <p className="text-gray-400 tracking-wide">Automated lead capture and qualification to fill your sales pipeline efficiently.</p>
                </div>
                <div className="p-8 rounded-none border border-white/10 hover:border-white/30 transition-all bg-white/5">
                  <Database className="w-12 h-12 text-white mb-4 floating" />
                  <h3 className="text-xl font-bold mb-4 tracking-wide">CRM Integration</h3>
                  <p className="text-gray-400 tracking-wide">Seamless integration with popular CRM platforms for enhanced workflow automation.</p>
                </div>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <div className="p-12 border border-white/10 bg-gradient-to-r from-white/5 to-white/10">
                <h2 className="text-4xl font-bold mb-6 text-glow tracking-tight">Ready to Transform Your Business?</h2>
                <p className="text-xl text-gray-400 mb-8 tracking-wide">
                  Schedule a call with our AI experts and discover how TRW.AI can revolutionize your operations.
                </p>
                <button 
                  onClick={handleBookCall}
                  className="group px-8 py-4 bg-white text-black text-lg hover:bg-gray-200 transition-all ring-glow flex items-center gap-2 mx-auto tracking-wide"
                >
                  Book a Call
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </section>

          {/* Footer */}
          <footer className="py-8 border-t border-white/10">
            <div className="max-w-7xl mx-auto px-4 text-center text-gray-400">
              <p className="tracking-wide">© 2024 TRW.AI. All rights reserved.</p>
            </div>
          </footer>
        </div>
      } />
    </Routes>
  );
}

export default App;