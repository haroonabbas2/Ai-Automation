import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Circle, ArrowLeft, ArrowRight, Bookmark, Share2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { format } from 'date-fns';
import { blogPosts, comments } from '../data/blog';
import { BlogPost } from '../types/blog';
import CommentSection from '../components/CommentSection';

const BlogPostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [savedPosts, setSavedPosts] = useState<number[]>([]);
  const [showShareMessage, setShowShareMessage] = useState(false);

  useEffect(() => {
    const currentPost = blogPosts.find(p => p.slug === slug);
    if (currentPost) {
      setPost(currentPost);
    } else {
      navigate('/blog');
    }
  }, [slug, navigate]);

  if (!post) return null;

  const currentIndex = blogPosts.findIndex(p => p.id === post.id);
  const prevPost = currentIndex > 0 ? blogPosts[currentIndex - 1] : null;
  const nextPost = currentIndex < blogPosts.length - 1 ? blogPosts[currentIndex + 1] : null;

  const toggleSavePost = () => {
    setSavedPosts(prev => 
      prev.includes(post.id) 
        ? prev.filter(id => id !== post.id)
        : [...prev, post.id]
    );
  };

  const handleShare = async () => {
    const url = window.location.href;

    try {
      if (navigator.share) {
        await navigator.share({
          title: post.title,
          url: url
        });
      } else {
        await navigator.clipboard.writeText(url);
        setShowShareMessage(true);
        setTimeout(() => setShowShareMessage(false), 3000);
      }
    } catch (error) {
      console.error('Error sharing:', error);
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(url);
        setShowShareMessage(true);
        setTimeout(() => setShowShareMessage(false), 3000);
      } catch (clipboardError) {
        console.error('Error copying to clipboard:', clipboardError);
      }
    }
  };

  const postComments = comments.filter(comment => comment.postId === post.id);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-black/50 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Circle className="w-8 h-8 text-white" />
              <span className="ml-2 text-xl font-bold text-glow tracking-wider">TRW.AI</span>
            </div>
            <button
              onClick={() => navigate('/blog')}
              className="flex items-center text-gray-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Blog
            </button>
          </div>
        </div>
      </nav>

      {/* Share Success Message */}
      {showShareMessage && (
        <div className="fixed bottom-4 right-4 bg-white text-black px-4 py-2 rounded-sm shadow-lg z-50 animate-fade-in">
          URL copied to clipboard!
        </div>
      )}

      {/* Main Content */}
      <div className="pt-32 pb-20 px-4">
        <article className="max-w-4xl mx-auto">
          {/* Breadcrumbs */}
          <nav className="flex items-center gap-2 text-sm mb-8 text-gray-400">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link to="/blog" className="hover:text-white transition-colors">Blog</Link>
            <span>/</span>
            <span className="text-white">{post.title}</span>
          </nav>

          {/* Article Header */}
          <header className="mb-12">
            <div className="flex items-center gap-2 mb-4">
              {post.categories.map((category, index) => (
                <span
                  key={index}
                  className="text-xs text-gray-400 bg-white/5 px-2 py-1"
                >
                  {category}
                </span>
              ))}
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-glow tracking-tight">
              {post.title}
            </h1>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <img
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <p className="font-medium">{post.author.name}</p>
                  <p className="text-sm text-gray-400">
                    {format(new Date(post.date), 'MMM d, yyyy')} · {post.readTime}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleShare}
                  className="p-2 text-gray-400 hover:text-white transition-colors"
                >
                  <Share2 className="w-5 h-5" />
                </button>
                <button
                  onClick={toggleSavePost}
                  className={`p-2 transition-colors ${
                    savedPosts.includes(post.id) ? 'text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Bookmark className="w-5 h-5" />
                </button>
              </div>
            </div>
          </header>

          {/* Cover Image */}
          <img
            src={post.coverImage}
            alt={post.title}
            className="w-full h-[400px] object-cover mb-12"
          />

          {/* Article Content */}
          <div className="prose prose-invert max-w-none mb-12">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-12">
            {post.tags.map((tag, index) => (
              <span
                key={index}
                className="text-sm text-gray-400 bg-white/5 px-3 py-1 hover:bg-white/10 transition-colors cursor-pointer"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Author Bio */}
          <div className="bg-white/5 border border-white/10 p-6 mb-12">
            <div className="flex items-start gap-6">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="w-16 h-16 rounded-full"
              />
              <div>
                <h3 className="text-xl font-bold mb-1">{post.author.name}</h3>
                <p className="text-gray-400 text-sm mb-3">{post.author.role}</p>
                <p className="text-gray-300">{post.author.bio}</p>
              </div>
            </div>
          </div>

          {/* Post Navigation */}
          <div className="grid md:grid-cols-2 gap-4 mb-12">
            {prevPost && (
              <Link
                to={`/blog/${prevPost.slug}`}
                className="group bg-white/5 border border-white/10 p-6 hover:bg-white/10 transition-colors"
              >
                <span className="flex items-center text-sm text-gray-400 mb-2">
                  <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
                  Previous Article
                </span>
                <h4 className="font-medium tracking-tight">{prevPost.title}</h4>
              </Link>
            )}
            {nextPost && (
              <Link
                to={`/blog/${nextPost.slug}`}
                className="group bg-white/5 border border-white/10 p-6 hover:bg-white/10 transition-colors md:text-right"
              >
                <span className="flex items-center justify-end text-sm text-gray-400 mb-2">
                  Next Article
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
                <h4 className="font-medium tracking-tight">{nextPost.title}</h4>
              </Link>
            )}
          </div>

          {/* Comments Section */}
          <CommentSection comments={postComments} postId={post.id} />
        </article>
      </div>
    </div>
  );
};

export default BlogPostPage;