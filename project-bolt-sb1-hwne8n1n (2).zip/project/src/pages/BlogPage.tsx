import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Circle, ArrowLeft, Search, Bookmark, Share2 } from 'lucide-react';
import { blogPosts } from '../data/blog';
import { removeSplineLogo } from '../utils/removeSplineLogo';
import BlogSearch from '../components/BlogSearch';
import { format } from 'date-fns';

const BlogPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [savedPosts, setSavedPosts] = useState<number[]>([]);
  const [showShareMessage, setShowShareMessage] = useState(false);

  const filteredPosts = blogPosts.filter(post => 
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.categories.some(cat => cat.toLowerCase().includes(searchQuery.toLowerCase())) ||
    post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const toggleSavePost = (postId: number) => {
    setSavedPosts(prev => 
      prev.includes(postId) 
        ? prev.filter(id => id !== postId)
        : [...prev, postId]
    );
  };

  const handleShare = async (title: string, slug: string) => {
    const url = `${window.location.origin}/blog/${slug}`;

    try {
      if (navigator.share) {
        await navigator.share({
          title: title,
          url: url
        });
      } else {
        await navigator.clipboard.writeText(url);
        setShowShareMessage(true);
        setTimeout(() => setShowShareMessage(false), 3000);
      }
    } catch (error) {
      console.error('Error sharing:', error);
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(url);
        setShowShareMessage(true);
        setTimeout(() => setShowShareMessage(false), 3000);
      } catch (clipboardError) {
        console.error('Error copying to clipboard:', clipboardError);
      }
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-black/50 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Circle className="w-8 h-8 text-white" />
              <span className="ml-2 text-xl font-bold text-glow tracking-wider">TRW.AI</span>
            </div>
            <button
              onClick={() => navigate('/')}
              className="flex items-center text-gray-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      {/* Share Success Message */}
      {showShareMessage && (
        <div className="fixed bottom-4 right-4 bg-white text-black px-4 py-2 rounded-sm shadow-lg z-50 animate-fade-in">
          URL copied to clipboard!
        </div>
      )}

      {/* Main Content */}
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-glow tracking-tight">
              Blog & Insights
            </h1>
            <p className="text-xl text-gray-400 mb-8 max-w-3xl mx-auto tracking-wide">
              Explore the latest trends and insights in AI automation, lead generation, and business transformation.
            </p>
            <BlogSearch onSearch={handleSearch} />
          </div>

          {/* Blog Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article key={post.id} className="bg-white/5 border border-white/10 group">
                <Link to={`/blog/${post.slug}`}>
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                </Link>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    {post.categories.map((category, index) => (
                      <span
                        key={index}
                        className="text-xs text-gray-400 bg-white/5 px-2 py-1"
                      >
                        {category}
                      </span>
                    ))}
                  </div>
                  <Link to={`/blog/${post.slug}`}>
                    <h2 className="text-xl font-bold mb-2 group-hover:text-glow transition-all tracking-tight">
                      {post.title}
                    </h2>
                  </Link>
                  <p className="text-gray-400 mb-4 tracking-wide">{post.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={post.author.avatar}
                        alt={post.author.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <p className="text-sm font-medium">{post.author.name}</p>
                        <p className="text-xs text-gray-400">
                          {format(new Date(post.date), 'MMM d, yyyy')} · {post.readTime}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleShare(post.title, post.slug)}
                        className="p-2 text-gray-400 hover:text-white transition-colors"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => toggleSavePost(post.id)}
                        className={`p-2 transition-colors ${
                          savedPosts.includes(post.id) ? 'text-white' : 'text-gray-400 hover:text-white'
                        }`}
                      >
                        <Bookmark className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;