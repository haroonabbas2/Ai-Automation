import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Circle, ArrowLeft, Share2, ArrowRight, Bot, Target, Mail, Zap, Users, LineChart, Shield, Brain, MessageSquare, Database } from 'lucide-react';
import { removeSplineLogo } from '../utils/removeSplineLogo';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  slug: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "How AI Automation Transforms Business Operations",
    excerpt: "Discover how AI-powered automation is revolutionizing business processes and driving efficiency across industries.",
    readTime: "5 min read",
    date: "Mar 26, 2024",
    slug: "ai-automation-transforms-business"
  },
  {
    id: 2,
    title: "Maximizing ROI with Smart Lead Generation",
    excerpt: "Learn how intelligent lead generation strategies can significantly improve your return on investment.",
    readTime: "4 min read",
    date: "Mar 25, 2024",
    slug: "maximizing-roi-lead-generation"
  },
  {
    id: 3,
    title: "Email Sync: The Future of Business Communication",
    excerpt: "Explore how email synchronization is changing the landscape of business communication.",
    readTime: "6 min read",
    date: "Mar 24, 2024",
    slug: "email-sync-future"
  },
  {
    id: 4,
    title: "Case Study: AI Automation Success Stories",
    excerpt: "Real-world examples of businesses achieving remarkable results through AI automation implementation.",
    readTime: "7 min read",
    date: "Mar 23, 2024",
    slug: "ai-automation-case-studies"
  },
  {
    id: 5,
    title: "Lead Generation Strategies for 2024",
    excerpt: "Stay ahead of the curve with the latest lead generation techniques and strategies for 2024.",
    readTime: "5 min read",
    date: "Mar 22, 2024",
    slug: "lead-generation-strategies-2024"
  },
  {
    id: 6,
    title: "Email Integration Best Practices",
    excerpt: "Master the art of email integration with these proven best practices and guidelines.",
    readTime: "4 min read",
    date: "Mar 21, 2024",
    slug: "email-integration-best-practices"
  },
  {
    id: 7,
    title: "AI Tools for Business Growth",
    excerpt: "Discover the essential AI tools that can accelerate your business growth and success.",
    readTime: "6 min read",
    date: "Mar 20, 2024",
    slug: "ai-tools-business-growth"
  },
  {
    id: 8,
    title: "Building an Effective Lead Pipeline",
    excerpt: "Learn how to construct and maintain a robust lead pipeline that drives consistent growth.",
    readTime: "5 min read",
    date: "Mar 19, 2024",
    slug: "effective-lead-pipeline"
  },
  {
    id: 9,
    title: "Email Automation Tips for Professionals",
    excerpt: "Professional tips and tricks to maximize the potential of your email automation systems.",
    readTime: "4 min read",
    date: "Mar 18, 2024",
    slug: "email-automation-tips"
  },
  {
    id: 10,
    title: "Future Trends in Business Automation",
    excerpt: "Get ahead of the curve with insights into upcoming trends in business automation technology.",
    readTime: "6 min read",
    date: "Mar 17, 2024",
    slug: "future-business-automation-trends"
  }
];

const AboutPage: React.FC = () => {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    const cleanup = removeSplineLogo();
    return cleanup;
  }, []);

  const handleBookCall = () => {
    navigate('/consultation');
  };

  const handleShare = (title: string) => {
    if (navigator.share) {
      navigator.share({
        title: title,
        url: window.location.href
      });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Spline Background */}
      <div className="fixed inset-0 z-0 opacity-50">
        <spline-viewer url="https://prod.spline.design/K8DugpAv9ziAjSRv/scene.splinecode"></spline-viewer>
      </div>

      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-black/50 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Circle className="w-8 h-8 text-white" />
              <span className="ml-2 text-xl font-bold text-glow tracking-wider">TRW.AI</span>
            </div>
            <button
              onClick={() => navigate('/')}
              className="flex items-center text-gray-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-4">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-glow tracking-tight">
              Transforming Business Through AI
            </h1>
            <p className="text-xl text-gray-400 mb-12 max-w-3xl mx-auto tracking-wide">
              We combine cutting-edge AI technology with industry expertise to deliver powerful automation solutions that drive business growth and efficiency.
            </p>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-20 px-4 bg-white/5">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold mb-16 text-center text-glow tracking-tight">Our Services</h2>
            
            {/* AI Automation */}
            <div className="mb-24">
              <div className="flex flex-col md:flex-row items-start gap-12">
                <div className="w-full md:w-1/2">
                  <div className="flex items-center mb-6">
                    <Bot className="w-8 h-8 text-white mr-4" />
                    <h3 className="text-2xl font-bold tracking-tight">AI Automation Services</h3>
                  </div>
                  <p className="text-gray-400 mb-6 tracking-wide">
                    Our AI automation solutions streamline your business processes, reduce operational costs, and improve efficiency across your organization.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <Zap className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Intelligent process automation for repetitive tasks</span>
                    </li>
                    <li className="flex items-start">
                      <Users className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Smart customer service automation with AI chatbots</span>
                    </li>
                    <li className="flex items-start">
                      <LineChart className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Real-time analytics and performance monitoring</span>
                    </li>
                  </ul>
                </div>
                <div className="w-full md:w-1/2 bg-white/5 border border-white/10 p-8">
                  <h4 className="text-xl font-bold mb-4 tracking-tight">Implementation Process</h4>
                  <ol className="space-y-4">
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">1</span>
                      <span className="text-gray-300 tracking-wide">Assessment of current processes and automation opportunities</span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">2</span>
                      <span className="text-gray-300 tracking-wide">Custom AI solution design and development</span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">3</span>
                      <span className="text-gray-300 tracking-wide">Integration with existing systems and workflows</span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">4</span>
                      <span className="text-gray-300 tracking-wide">Training and ongoing optimization</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>

            {/* Lead Generation */}
            <div className="mb-24">
              <div className="flex flex-col md:flex-row items-start gap-12">
                <div className="w-full md:w-1/2">
                  <div className="flex items-center mb-6">
                    <Target className="w-8 h-8 text-white mr-4" />
                    <h3 className="text-2xl font-bold tracking-tight">Lead Generation</h3>
                  </div>
                  <p className="text-gray-400 mb-6 tracking-wide">
                    Our data-driven lead generation approach helps you identify, attract, and convert high-quality prospects into valuable customers.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <Brain className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">AI-powered lead scoring and qualification</span>
                    </li>
                    <li className="flex items-start">
                      <MessageSquare className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Automated engagement and nurturing campaigns</span>
                    </li>
                    <li className="flex items-start">
                      <Database className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Advanced analytics and ROI tracking</span>
                    </li>
                  </ul>
                </div>
                <div className="w-full md:w-1/2 bg-white/5 border border-white/10 p-8">
                  <h4 className="text-xl font-bold mb-4 tracking-tight">Success Metrics</h4>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <span className="text-2xl font-bold text-white mr-4">3x</span>
                      <span className="text-gray-300 tracking-wide">Increase in qualified lead generation</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-2xl font-bold text-white mr-4">50%</span>
                      <span className="text-gray-300 tracking-wide">Reduction in lead acquisition costs</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-2xl font-bold text-white mr-4">85%</span>
                      <span className="text-gray-300 tracking-wide">Improvement in lead conversion rates</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Email Synchronization */}
            <div>
              <div className="flex flex-col md:flex-row items-start gap-12">
                <div className="w-full md:w-1/2">
                  <div className="flex items-center mb-6">
                    <Mail className="w-8 h-8 text-white mr-4" />
                    <h3 className="text-2xl font-bold tracking-tight">Email Synchronization</h3>
                  </div>
                  <p className="text-gray-400 mb-6 tracking-wide">
                    Seamlessly integrate and automate your email communications with our advanced synchronization platform.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <Shield className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Enterprise-grade security and encryption</span>
                    </li>
                    <li className="flex items-start">
                      <Zap className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Real-time synchronization across devices</span>
                    </li>
                    <li className="flex items-start">
                      <Users className="w-5 h-5 text-white mr-3 mt-1" />
                      <span className="text-gray-300 tracking-wide">Team collaboration and workflow automation</span>
                    </li>
                  </ul>
                </div>
                <div className="w-full md:w-1/2 bg-white/5 border border-white/10 p-8">
                  <h4 className="text-xl font-bold mb-4 tracking-tight">Key Features</h4>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">✓</span>
                      <span className="text-gray-300 tracking-wide">Automated email categorization and prioritization</span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">✓</span>
                      <span className="text-gray-300 tracking-wide">Smart templates and response automation</span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mr-3 mt-1">✓</span>
                      <span className="text-gray-300 tracking-wide">Advanced analytics and reporting</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Section */}
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold mb-16 text-center text-glow tracking-tight">Latest Insights</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post) => (
                <article key={post.id} className="bg-white/5 border border-white/10 p-6 hover:bg-white/10 transition-colors">
                  <h3 className="text-xl font-bold mb-4 tracking-tight">{post.title}</h3>
                  <p className="text-gray-400 mb-4 tracking-wide">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <span>{post.date}</span>
                      <span>{post.readTime}</span>
                    </div>
                    <button
                      onClick={() => handleShare(post.title)}
                      className="text-gray-400 hover:text-white transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="p-12 border border-white/10 bg-gradient-to-r from-white/5 to-white/10">
              <h2 className="text-4xl font-bold mb-6 text-glow tracking-tight">Ready to Transform Your Business?</h2>
              <p className="text-xl text-gray-400 mb-8 tracking-wide">
                Schedule a consultation with our AI experts and discover how we can help you achieve your business goals.
              </p>
              <button 
                onClick={handleBookCall}
                className="group px-8 py-4 bg-white text-black text-lg hover:bg-gray-200 transition-all ring-glow flex items-center gap-2 mx-auto tracking-wide"
              >
                Book a Call
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 text-center text-gray-400">
            <p className="tracking-wide">© 2024 TRW.AI. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default AboutPage;