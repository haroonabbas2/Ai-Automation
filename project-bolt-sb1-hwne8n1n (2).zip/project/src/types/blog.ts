export interface Author {
  id: string;
  name: string;
  role: string;
  avatar: string;
  bio: string;
}

export interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  author: Author;
  date: string;
  readTime: string;
  categories: string[];
  tags: string[];
}

export interface Comment {
  id: number;
  postId: number;
  author: string;
  content: string;
  date: string;
  avatar: string;
}