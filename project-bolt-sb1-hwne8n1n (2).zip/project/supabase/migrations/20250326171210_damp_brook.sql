/*
  # Update contact submissions table

  1. Changes
    - Create contact_submissions table if it doesn't exist
    - Add email validation constraint
    - Enable RLS
    - Add policies for insert and select operations

  2. Security
    - Enable RLS on contact_submissions table
    - Add policy for anonymous users to insert data
    - Add policy for authenticated users to view submissions
*/

-- Create the table if it doesn't exist
CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  full_name text NOT NULL,
  email text NOT NULL,
  company_name text NOT NULL,
  service text NOT NULL,
  problem_description text NOT NULL,
  additional_info text,
  CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Enable RLS
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and create new ones
DO $$ 
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Anyone can insert contact submissions" ON contact_submissions;
  DROP POLICY IF EXISTS "Only authenticated users can view submissions" ON contact_submissions;
  
  -- Create new policies
  CREATE POLICY "Anyone can insert contact submissions"
    ON contact_submissions
    FOR INSERT
    TO anon
    WITH CHECK (true);

  CREATE POLICY "Only authenticated users can view submissions"
    ON contact_submissions
    FOR SELECT
    TO authenticated
    USING (true);
END $$;